from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)
model = pickle.load(open('model/model_campus.pkl', 'rb'))

@app.route('/hello')
@app.route('/hello/<name>')
def hello_world(name=""):
    if (name):
        return "Hello " + str(name)
    else:
        return 'Hello, PYTN 70!'
    
@app.route('/')
def main():
    return render_template('main.html')

@app.route('/predict', methods=["POST"])
def predict_placement():
    # terima input dari file html, kita ubah format jadi np.array 2D, 4 kolom untuk 4 fitur
    # supaya bisa digunakan di model machine learning kita
    fitur = []
    for x in request.form.values():
        fitur.append(int(x))
    # ubah jadi 2D
    fitur = [fitur]
    # ubah jadi numpy array
    fitur = np.array(fitur).reshape((1,4))
    
    # gunakan machine learning model kita (udah di import di atas kan) untuk bikin prediksi  
    hasil_prediksi = model.predict(fitur) #diterima/tidak
    
    # format hasil text yang ditampilkan
    output = {"Not Placed": "tidak diterima", "Placed": "diterima"}    
    hasil = output[hasil_prediksi[0]]
    
    # hasil prediksi dikirim balik ke html untuk di display ke user    
    return render_template('main.html', prediction_text='Student sepertinya akan {} ke tempat kerja. Nilai student adalah sebagai berikut: smp {}, sma {}, S1 {}, tes masuk {}'.format(hasil, fitur[0,0], fitur[0,1], fitur[0,2], fitur[0,3]))
